require("dotenv").config();

const required = [
  "DATABASE_URL",
  "JWT_ACCESS_SECRET",
  "JWT_REFRESH_SECRET",
  "REDIS_URL",
  "PAYSTACK_SECRET_KEY",
  "MONNIFY_API_KEY",
  "MONNIFY_SECRET_KEY",
  "MONNIFY_CONTRACT_CODE",
  "SME_API_KEY",
  "SME_API_BASE_URL",
  "VTUNG_API_KEY",
  "VTUNG_BASE_URL",
  "MULTITEXTER_API_KEY",
  "AIRALO_CLIENT_ID",
  "AIRALO_CLIENT_SECRET",
  "RESEND_API_KEY",
  "GOOGLE_CLIENT_ID",
  "GOOGLE_CLIENT_SECRET",
  "GOOGLE_CALLBACK_URL",
  "SUPPORT_WHATSAPP_NUMBER",
];

for (const key of required) {
  if (!process.env[key]) {
    throw new Error(`Missing required environment variable: ${key}`);
  }
}

module.exports = {
  nodeEnv: process.env.NODE_ENV || "development",
  port: parseInt(process.env.PORT, 10) || 5000,
  appUrl: process.env.APP_URL || "http://localhost:5000",
  frontendUrl: process.env.FRONTEND_URL || "http://localhost:5173",

  jwt: {
    accessSecret: process.env.JWT_ACCESS_SECRET,
    refreshSecret: process.env.JWT_REFRESH_SECRET,
    accessExpiresIn: process.env.JWT_ACCESS_EXPIRES_IN || "15m",
    refreshExpiresIn: process.env.JWT_REFRESH_EXPIRES_IN || "30d",
  },

  redisUrl: process.env.REDIS_URL,

  paystack: {
    secretKey: process.env.PAYSTACK_SECRET_KEY,
    publicKey: process.env.PAYSTACK_PUBLIC_KEY,
  },

  monnify: {
    apiKey: process.env.MONNIFY_API_KEY,
    secretKey: process.env.MONNIFY_SECRET_KEY,
    contractCode: process.env.MONNIFY_CONTRACT_CODE,
    baseUrl: process.env.MONNIFY_BASE_URL || "https://sandbox.monnify.com",
  },

  smeApi: {
    apiKey: process.env.SME_API_KEY,
    baseUrl: process.env.SME_API_BASE_URL,
  },

  vtuNg: {
    apiKey: process.env.VTUNG_API_KEY,
    baseUrl: process.env.VTUNG_BASE_URL,
  },

  multitexter: {
    // API key from: https://web.multitexter.com/dashboard/profile-summary → "Get API Key"
    // Base URL is fixed per the v2 docs — no sandbox environment is documented.
    apiKey: process.env.MULTITEXTER_API_KEY,
    baseUrl: process.env.MULTITEXTER_BASE_URL || "https://app.multitexter.com",
  },

  airalo: {
    clientId: process.env.AIRALO_CLIENT_ID,
    clientSecret: process.env.AIRALO_CLIENT_SECRET,
    baseUrl: process.env.AIRALO_BASE_URL || "https://sandbox-partners-api.airalo.com",
  },

  resend: {
    apiKey:    process.env.RESEND_API_KEY,
    fromEmail: process.env.FROM_EMAIL || "noreply@elitehub.ng",
  },

  google: {
    clientId:     process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackUrl:  process.env.GOOGLE_CALLBACK_URL,
  },

  anthropic: {
    apiKey: process.env.ANTHROPIC_API_KEY,
    model: process.env.ANTHROPIC_MODEL || "claude-sonnet-4-6",
  },

  support: {
    // wa.me format: digits only, country code, no "+" or spaces (e.g. 2348012345678)
    whatsappNumber: process.env.SUPPORT_WHATSAPP_NUMBER,
  },
};
